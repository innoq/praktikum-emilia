import { defineConfig } from "vite";

export default defineConfig({
    server: {
        cors: "https://edge-config.vercel.com"
    }
})